//
//  MainViewController.swift
//  BeActive
//
//  Created by Konstantin Khokhlov on 07.06.17.
//  Copyright © 2017 Konstantin Khokhlov. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {}
